import streamlit as st
import sys
from importlib import reload
import pandas as pd
from pyrpa.UI import common
import pyrpa
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

@st.cache
def do_nothing():
    pass


if sys.version_info[0] < 3:
    reload(sys)
    sys.setdefaultencoding("utf-8")

st.sidebar.markdown("## Parameters")

# set an empty temporary dictionary

_temp_dict = None

index = ['Dict Type', 'Description', 'Filename', 'Grade Field', 'XYZ Fields',
         'Domain Field', 'Domains', 'Weight Field', 'Invalid Numbers',
         'Low Cap', 'Selected Cap', 'High Cap',
         'XYZ Plane',
         'Histogram Bin', 'Histogram X Max', 'Histogram Y Max',
         'Settings File']

defaults = ['Capping', "[Project Description]", '--None--', '--None--', '',
            '--None--', '', '--None--', 'Ignore',
            -99., -99., -99.,
            '--None--',
            5., -99., -99.,
            '']

print_layout=False

if _temp_dict is None:
    _temp_dict = pd.DataFrame({'Parameter': defaults}, index=index) # create a df with the "defaults" list

if st.sidebar.checkbox("Load Settings"):
    settings_files = common.get_dict_files("Capping")
    settings_file = st.sidebar.selectbox("Capping Settings File", settings_files, key="Capping Settings File")
    settings_df = pd.read_csv(settings_file, index_col=0)
    _temp_dict = settings_df

#

xyzfields = common.strip_dflist(_temp_dict.loc['XYZ Fields', 'Parameter'])
domains = common.strip_dflist(_temp_dict.loc['Domains', 'Parameter'])

_temp_dict.loc['Description', 'Parameter'] = st.sidebar.text_input("Description", _temp_dict.loc['Description', 'Parameter'])
infiles = common.get_file_list([".csv", ".dm"])
_temp_dict.loc['Filename', 'Parameter'] = common.selectbox(selection=_temp_dict.loc['Filename', 'Parameter'],
                                                                options=infiles,
                                                                display_text="Data File (.csv or .dm)",
                                                                key='Filename')

# big outer if is checking to see if filename is defined

if _temp_dict.loc['Filename', 'Parameter'] != "--None--":
    df = common.load_file(_temp_dict.loc['Filename', 'Parameter'])
    header = common.get_header(df)

    _temp_dict.loc['Grade Field', 'Parameter'] = common.selectbox(selection=_temp_dict.loc['Grade Field', 'Parameter'],
                                                                       options=header,
                                                                       display_text="Grade Field",
                                                                       key='Grade Field')

    xyzfields, _temp_dict.loc['XYZ Fields', 'Parameter'] = common.multiselect(options=header,
                                                                              display_text='XYZ Fields',
                                                                              default_list=xyzfields,
                                                                              default_dictval=_temp_dict.loc['XYZ Fields', 'Parameter'],
                                                                              key='XYZ Fields',
                                                                              guessheader=True,
                                                                              field_type='xyzfields')

    _temp_dict.loc['Domain Field', 'Parameter'] = common.selectbox(selection=_temp_dict.loc['Domain Field', 'Parameter'],
                                                                  options=header,
                                                                  display_text="Domain Field",
                                                                  key='Domain Field')

    if _temp_dict.loc['Domain Field', 'Parameter'] != "--None--":

        domain_options = df[_temp_dict.loc['Domain Field', 'Parameter']].unique()
        df[_temp_dict.loc['Domain Field', 'Parameter']] = df[_temp_dict.loc['Domain Field', 'Parameter']].apply(lambda x: str(x))
        domain_options = [str(i) for i in domain_options]

        domains, _temp_dict.loc['Domains', 'Parameter'] = common.multiselect(options=domain_options,
                                                                             display_text='Domains',
                                                                             default_list=domains,
                                                                             default_dictval=_temp_dict.loc['Domains', 'Parameter'],
                                                                             key='Domains',
                                                                             guessheader=False,
                                                                             field_type='domains')

        if len(domains) > 0:
            df_filt = df[df[_temp_dict.loc['Domain Field', 'Parameter']].isin(domains)].copy().reset_index(drop=True)
        else:
            df_filt = df.copy().reset_index(drop=True)
    else:
        df_filt = df.copy().reset_index(drop=True)

    _temp_dict.loc['Weight Field', 'Parameter'] = common.selectbox(selection=_temp_dict.loc['Weight Field', 'Parameter'],
                                                                  options=header,
                                                                  display_text="Weight Field",
                                                                  key='Weight Field')

    if _temp_dict.loc['Weight Field', 'Parameter'] == '--None--':
        weightf = None
    else:
        weightf = _temp_dict.loc['Weight Field', 'Parameter']

    if _temp_dict.loc['Grade Field', 'Parameter'] != "--None--" and len(xyzfields) == 3:

        idx = common.get_idx(['Ignore', 'Replace with Zero'], _temp_dict.loc['Invalid Numbers', 'Parameter']) # idx = index

        _temp_dict.loc['Invalid Numbers', 'Parameter'] = st.sidebar.radio("Invalid Number Handling",
                                                                          ['Ignore', 'Replace with Zero'],
                                                                          index=idx)

        df_valid = common.invalid_number_handling(df_filt, _temp_dict.loc['Grade Field', 'Parameter'],
                                                  _temp_dict.loc['Invalid Numbers', 'Parameter'])

        df_valid = df_valid.sort_values(by=[_temp_dict.loc['Grade Field', 'Parameter']]) # final df after validations and filters

        smp_obj = pyrpa.smp.Sample(data=df_valid,
                                   gradefields=[_temp_dict.loc['Grade Field', 'Parameter']],
                                   holeid=None,
                                   xyzfields=xyzfields,
                                   weightf=weightf)

        # defining the default low, selected, and high cap from the df_valid
        if float(_temp_dict.loc['Low Cap', 'Parameter']) == -99.:
            _temp_dict.loc['Low Cap', 'Parameter'] = round(smp_obj.data[_temp_dict.loc['Grade Field', 'Parameter']].quantile(0.95),2) # smp_obj.data is calling the "df_valid"
        if float(_temp_dict.loc['Selected Cap', 'Parameter']) == -99.:
            _temp_dict.loc['Selected Cap', 'Parameter'] = round(smp_obj.data[_temp_dict.loc['Grade Field', 'Parameter']].quantile(0.975),2)
        if float(_temp_dict.loc['High Cap', 'Parameter']) == -99.:
            _temp_dict.loc['High Cap', 'Parameter'] = round(smp_obj.data[_temp_dict.loc['Grade Field', 'Parameter']].quantile(0.99),2)

        smp_obj.data['Capping Levels'] = 'Uncapped'
        smp_obj.data['Point Size'] = 0.1
        point_sizes = [0.5, 1.0, 1.5]
        smp_obj.data['Point Size3D'] = 1

        for s, i in enumerate(['Low Cap', 'Selected Cap', 'High Cap']):
            # defining capping level
            _temp_dict.loc[i, 'Parameter'] = float(st.sidebar.text_input(i, value=_temp_dict.loc[i, 'Parameter'], key=i))
            filt = smp_obj.data[_temp_dict.loc['Grade Field', 'Parameter']] >= _temp_dict.loc[i, 'Parameter']
            smp_obj.data['Capping Levels'][filt] = i
            smp_obj.data['Point Size'][filt] = point_sizes[s]
            smp_obj.data['Point Size3D'][filt] = float(s + 3)

        # _temp_dict.to_csv('_temp_cap_dict')

        smp_obj.data['Point Size'][smp_obj.data[_temp_dict.loc['Grade Field', 'Parameter']] == smp_obj.data[_temp_dict.loc['Grade Field', 'Parameter']].max()] = 5.

        # save settings stuff ------------------------------------------------------------------------------------------------

        _temp_dict.loc['Settings File', 'Parameter'] = st.sidebar.text_input("Save Capping Settings",
                                                                             value=_temp_dict.loc['Settings File', 'Parameter'],
                                                                             key='Settings File')

        if ".dict" not in _temp_dict.loc['Settings File', 'Parameter'] and _temp_dict.loc['Settings File', 'Parameter'] != ' ':
            _temp_dict.loc['Settings File', 'Parameter'] += ".dict"

        if st.sidebar.button('Save', key='save settings'):
            _temp_dict.to_csv(_temp_dict.loc['Settings File', 'Parameter'])


        if st.sidebar.checkbox("Print layout"):
            print_layout = True
        try:
            _temp_dict2 = pd.read_csv('_temp_cap_dict', index_col=0)
            # revert to previously set settings
            _temp_dict.loc['XYZ Plane', 'Parameter'] = _temp_dict2.loc['XYZ Plane', 'Parameter']
            _temp_dict.loc['Histogram Bin', 'Parameter'] = _temp_dict2.loc['Histogram Bin', 'Parameter']
            _temp_dict.loc['Histogram X Max', 'Parameter'] = _temp_dict2.loc['Histogram X Max', 'Parameter']
            _temp_dict.loc['Histogram Y Max', 'Parameter'] = _temp_dict2.loc['Histogram Y Max', 'Parameter']
        except:
            pass

        common.show_header()
        st.title("Capping Analysis") # main screen

        st.markdown("Description: `" + _temp_dict.loc['Description', 'Parameter'] + "`")
        st.markdown("Filename: `" + _temp_dict.loc['Filename', 'Parameter'] + "`")
        st.markdown("Grade Field: `" + _temp_dict.loc['Grade Field', 'Parameter'] + "`")
        if _temp_dict.loc['Domain Field', 'Parameter'] != "--None--":
            st.markdown("Domain Filters: `" + _temp_dict.loc['Domain Field', 'Parameter'] + "` = `" + str(_temp_dict.loc['Domains', 'Parameter']) + "`")
        st.markdown("Weight Field: `" + _temp_dict.loc['Weight Field', 'Parameter'] + "`")

        st.info("## Capping Summary")

        # calculations showed in the screen start here
        cap_obj = pyrpa.capping(samples=smp_obj,
                                gradefield=_temp_dict.loc['Grade Field', 'Parameter'],
                                capping_levels=[float(_temp_dict.loc['Low Cap', 'Parameter']),
                                                float(_temp_dict.loc['Selected Cap', 'Parameter']),
                                                float(_temp_dict.loc['High Cap', 'Parameter'])])

        cap_stats = cap_obj.stats(cap=float(_temp_dict.loc['Selected Cap', 'Parameter'])) # generate the descriptive statistics

        st.table(cap_stats.astype(str)) # show the descriptive statistics

        labels = ["Uncapped", "Capped"]

        # Create subplots: use 'domain' type for Pie subplot
        fig = make_subplots(rows=1, cols=2, specs=[[{'type':'domain'}, {'type':'domain'}]]) # make_subplots - plotly command
        fig.add_trace(go.Pie(labels=labels, # add_trace - plotly command
                             values=[cap_stats.loc['Count', 'Capped']-cap_stats.loc['Number Capped', 'Capped'],
                                     cap_stats.loc['Number Capped', 'Capped']],
                             name="Sample Count"), 1, 1)
        fig.add_trace(go.Pie(labels=labels,
                             values=[100.-float(cap_stats.loc['Metal Loss', 'Capped'].strip("%")),
                                                    float(cap_stats.loc['Metal Loss', 'Capped'].strip("%"))],
                             name="Metal"),
                      1, 2)

        # Use `hole` to create a donut-like pie chart
        fig.update_traces(hole=.4, hoverinfo="label+percent+name")

        fig.update_layout(
            # Add annotations in the center of the donut pies.
            annotations=[dict(text='Capped Samples', x=0.15, y=0.5, font_size=10, showarrow=False),
                         dict(text='Metal Loss', x=0.82, y=0.5, font_size=10, showarrow=False)])

        st.plotly_chart(fig)

        if print_layout:
            common.make_whitespace(35)
            common.show_header()



        st.info("## 3D View")
        mycolors = ['rgb(32,32,32)', 'rgb(0,0,255)', 'rgb(0,255,0)', 'rgb(255,0,0)']
        fig = px.scatter_3d(smp_obj.data,
                            x=xyzfields[0],
                            y=xyzfields[1],
                            z=xyzfields[2],
                            color='Capping Levels',
                            color_discrete_sequence=mycolors,
                            size='Point Size3D', template='plotly_white')

        fig.update_layout(scene_aspectmode='data')
        st.plotly_chart(fig)

        if print_layout:
            common.make_whitespace(40)
            common.show_header()
            common.make_whitespace(2)

        st.info("## Orthogonal Data View")

        if not print_layout:
            xyzplanes = ['Plan View', 'East West', 'North South']
            _temp_dict.loc['XYZ Plane', 'Parameter'] = common.radio(selection=_temp_dict.loc['XYZ Plane', 'Parameter'],
                                                                    options=xyzplanes,
                                                                    display_text="",
                                                                    key='XYZ Plane')

        xmin, xmax = smp_obj.data[xyzfields[0]].min(), smp_obj.data[xyzfields[0]].max()
        ymin, ymax = smp_obj.data[xyzfields[1]].min(), smp_obj.data[xyzfields[1]].max()
        zmin, zmax = smp_obj.data[xyzfields[2]].min(), smp_obj.data[xyzfields[2]].max()

        xrange, yrange, zrange = xmax-xmin, ymax-ymin, zmax-zmin
        xc, yc, zc = xrange/2. + xmin, yrange/2. + ymin, zrange/2. + zmin
        xrange *= 1.1
        yrange *= 1.1
        zrange *= 1.1

        pl_suffix = ''

        if _temp_dict.loc['XYZ Plane', 'Parameter'] == 'Plan View':
            x=xyzfields[0]
            y=xyzfields[1]
            reverse_axis = False
            if xrange > yrange:
                srange = xrange
            else:
                srange = yrange
            xmin, ymin = xc - srange/2., yc - srange/2.
            xmax, ymax = xc + srange/2., yc + srange/2.
            pl_suffix = ' - Looking Down'

        if _temp_dict.loc['XYZ Plane', 'Parameter'] == 'East West':
            x = xyzfields[0]
            y = xyzfields[2]
            reverse_axis = False
            if xrange > zrange:
                srange = xrange
            else:
                srange = zrange
            xmin, ymin = xc - srange / 2., zc - srange / 2.
            xmax, ymax = xc + srange / 2., zc + srange / 2.
            pl_suffix = ' - Looking South'

        if _temp_dict.loc['XYZ Plane', 'Parameter'] == 'North South':
            x = xyzfields[1]
            y = xyzfields[2]
            reverse_axis = True
            if yrange > zrange:
                srange = yrange
            else:
                srange = zrange
            xmin, ymin = yc - srange / 2., zc - srange / 2.
            xmax, ymax = yc + srange / 2., zc + srange / 2.
            pl_suffix = ' - Looking West'

        fig = px.scatter(smp_obj.data,
                         x=x,
                         y=y,
                         color='Capping Levels',
                         color_discrete_sequence=mycolors,
                         size='Point Size')

        fig.update_layout(title=_temp_dict.loc['XYZ Plane', 'Parameter'] + pl_suffix,
                          scene_aspectmode='data',
                          width=900, height=900)
        fig.update_xaxes(range=[xmin, xmax])
        fig.update_yaxes(range=[ymin, ymax])
        fig.update_xaxes(tickangle=90)

        st.plotly_chart(fig)

        if print_layout:
            common.make_whitespace(44)
            common.show_header()

        st.info("## Decile Analysis")
        cap_obj.capping_levels =  [float(_temp_dict.loc['Low Cap', 'Parameter']),
                                   float(_temp_dict.loc['Selected Cap', 'Parameter']),
                                   float(_temp_dict.loc['High Cap', 'Parameter'])]
        dec_df = cap_obj.decile_analysis().style.format('{:20,.2f}')
        # st.table(dec_df)
        st.table(data=dec_df)

        if print_layout:
            common.make_whitespace(30)
            common.show_header()
            common.make_whitespace(2)

        st.info("## Log Probability Plot")
        cap_obj.capping_levels = cap_obj.capping_levels[:-1]
        fig = cap_obj.log_probability_plot(show_caps=True) # log_probability_plot is a function inside of capping.py
        st.pyplot(fig)

        if print_layout:
            common.make_whitespace(35)
            common.show_header()
            common.make_whitespace(5)

        st.info("## Histogram")

        if not print_layout:
            _temp_dict.loc['Histogram Bin', 'Parameter'] = float(st.text_input("Histogram Bin",
                                                                           value=_temp_dict.loc['Histogram Bin', 'Parameter']))

        if weightf is None:
            w = None
            ytitle = 'Count'
        else:
            w = smp_obj.data[weightf]
            ytitle = 'Sum of Weights'

        bins = np.arange(0.,
                         smp_obj.data[_temp_dict.loc['Grade Field', 'Parameter']].max() + float(_temp_dict.loc['Histogram Bin', 'Parameter']),
                         float(_temp_dict.loc['Histogram Bin', 'Parameter']))
        y, x = np.histogram(smp_obj.data[_temp_dict.loc['Grade Field', 'Parameter']],
                            weights=w,
                            bins=bins)
        x += float(_temp_dict.loc['Histogram Bin', 'Parameter'])/2.
        histdata = pd.DataFrame({'x': x[:-1], 'y': y})

        if float(_temp_dict.loc['Histogram X Max', 'Parameter']) == -99.:
            _temp_dict.loc['Histogram X Max', 'Parameter'] = smp_obj.data[
                _temp_dict.loc['Grade Field', 'Parameter']].max()
            _temp_dict.loc['Histogram Y Max', 'Parameter'] = np.max(y)

        if not print_layout:

            _temp_dict.loc['Histogram X Max', 'Parameter'] = st.text_input("Histogram X Max",
                                                                           value=_temp_dict.loc['Histogram X Max', 'Parameter'],
                                                                           key='Histogram X Max')

            _temp_dict.loc['Histogram Y Max', 'Parameter'] = st.text_input("Histogram Y Max",
                                                                           value=_temp_dict.loc[
                                                                               'Histogram Y Max', 'Parameter'],
                                                                           key='Histogram Y Max')

            # _temp_dict.loc['Histogram X Max', 'Parameter'] = st.slider("Histogram X Max",
            #                                                            0.,
            #                                                            float(smp_obj.data[_temp_dict.loc['Grade Field', 'Parameter']].max()),
            #                                                            float(_temp_dict.loc['Histogram X Max', 'Parameter']),
            #                                                            1., key='Histogram X Max')
            # _temp_dict.loc['Histogram Y Max', 'Parameter'] = st.slider("Histogram Y Max",
            #                                                            0.,
            #                                                            float(np.max(y)),
            #                                                            float(_temp_dict.loc['Histogram Y Max', 'Parameter']),
            #                                                            1., key='Histogram Y Max')

        fig = px.bar(histdata, x='x', y='y', template="plotly_white")
        fig['layout']['xaxis'].update(title=_temp_dict.loc['Grade Field', 'Parameter'], range=[0, _temp_dict.loc['Histogram X Max', 'Parameter']], autorange=False)
        fig['layout']['yaxis'].update(title=ytitle, range=[0, _temp_dict.loc['Histogram Y Max', 'Parameter']], autorange=False)
        st.plotly_chart(fig)

        if print_layout:
            common.make_whitespace(40)
            common.show_header()
            common.make_whitespace(5)

        st.info("## Disintegration Analysis")

        smp_obj.data["Metal Disintegration (1.0 - g(x)/g(x-1)*100)"] = cap_obj.disintegration_analysis()
        smp_obj.data['Disint_color'] = 0.
        smp_obj.data['Disint_color'][smp_obj.data["Metal Disintegration (1.0 - g(x)/g(x-1)*100)"]>15] = 1.
        fig = px.scatter(smp_obj.data.loc[int(len(smp_obj.data)*0.9):],
                      x=_temp_dict.loc['Grade Field', 'Parameter'],
                      y="Metal Disintegration (1.0 - g(x)/g(x-1)*100)",
                      color='Capping Levels',
                      color_discrete_sequence=mycolors,
                      size='Point Size')
        fig.update_layout(xaxis_type="log")
        st.plotly_chart(fig)

        if print_layout:
            common.make_whitespace(40)
            common.show_header()
            common.make_whitespace(5)
            st.info("## Parameters")
            st.table(_temp_dict)

        _temp_dict.to_csv('_temp_cap_dict')
